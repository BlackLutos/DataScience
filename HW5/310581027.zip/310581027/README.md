### Suggest
* See train.ipynb and test.ipynb
### Data position
* Put train.json and test.json in same directory
### Train
```
python train.py
```
### Test
```
python test.py
```
### Model
* T5-Base