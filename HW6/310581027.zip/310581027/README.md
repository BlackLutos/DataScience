* Produce the final result
```
python test.py
```
* Place the dataset in same directory